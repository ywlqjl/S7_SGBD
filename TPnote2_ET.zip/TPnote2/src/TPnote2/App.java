package TPnote2;

import java.sql.SQLException;



public class App {

	public static void main(String[] args) throws SQLException
	{
//		ConnectionDAO con = new ConnectionDAO();
//		con.connection();
//
		View view = new View(); 
		view.createWindow();
//		QuaiDAO qd = new QuaiDAO();
//		qd.nbDeQuai(1);
//		qd.Question2(1);

	}
}
